'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Play, Download, ArrowLeft, Star } from 'lucide-react';
import Link from 'next/link';
import ReactPlayer from 'react-player';
import { supabase } from '@/lib/supabase';

interface Movie {
  id: number;
  title: string;
  poster_path: string;
  backdrop_path: string;
  overview: string;
  vote_average: number;
  release_date: string;
}

export default function MoviePage() {
  const params = useParams();
  const router = useRouter();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('movies')
        .select('*')
        .eq('id', params.id)
        .single();

      if (data) {
        setMovie(data as Movie);
        return;
      }

      // Fallback demo movie if not found in Supabase (e.g. viewing a mock-data id)
      setMovie({
        id: Number(params.id),
        title: "Dune: Part Two",
        poster_path: "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9d7Z6J8w3e4vO.jpg",
        backdrop_path: "https://image.tmdb.org/t/p/original/5a4JdoFwll5DRtKMe7J0YhVa7tC.jpg",
        overview: "Paul Atreides unites with Chani and the Fremen while seeking revenge...",
        vote_average: 8.5,
        release_date: "2024-03-01"
      });
    }
    load();
  }, [params.id]);

  if (!movie) return <div className="min-h-screen bg-zinc-950 flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <div className="relative h-[70vh]">
        <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: `url(${movie.backdrop_path})`}} />
        <div className="absolute inset-0 bg-black/70" />
        
        <div className="absolute top-6 left-6 z-20">
          <button onClick={() => router.back()} className="flex items-center gap-2 text-white hover:text-rose-400">
            <ArrowLeft /> Back to Home
          </button>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-12 z-10">
          <div className="max-w-4xl">
            <h1 className="text-6xl font-bold mb-4">{movie.title}</h1>
            <div className="flex items-center gap-6 text-lg mb-8">
              <div className="flex items-center gap-2">
                <Star className="text-yellow-400" /> {movie.vote_average}
              </div>
              <div>{new Date(movie.release_date).getFullYear()}</div>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={() => setPlaying(true)}
                className="flex items-center gap-3 bg-white text-black px-12 py-4 rounded-2xl font-semibold text-lg hover:scale-105 transition"
              >
                <Play className="fill-current" /> WATCH NOW
              </button>
              <button className="flex items-center gap-3 border-2 border-white px-8 py-4 rounded-2xl font-semibold hover:bg-white hover:text-black transition">
                <Download /> DOWNLOAD
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Video Player Modal */}
      {playing && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          <div className="relative w-full max-w-5xl aspect-video bg-black">
            <button 
              onClick={() => setPlaying(false)}
              className="absolute -top-12 right-0 text-white z-50 text-xl"
            >
              ✕ CLOSE
            </button>
            <ReactPlayer 
              url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" 
              playing={true}
              controls={true}
              width="100%"
              height="100%"
              className="react-player"
            />
          </div>
        </div>
      )}

      <div className="max-w-4xl mx-auto px-8 py-16">
        <p className="text-xl text-zinc-300 leading-relaxed">{movie.overview}</p>
        
        {/* Cast, recommendations etc would go here */}
        <div className="mt-16 pt-16 border-t border-zinc-800">
          <h3 className="text-2xl mb-8">More like this</h3>
          {/* Add more cards */}
        </div>
      </div>
    </div>
  );
}
