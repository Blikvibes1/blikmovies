'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Users, Film, BarChart3, Settings, LogOut } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [authState, setAuthState] = useState<'checking' | 'denied' | 'ok'>('checking');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'done' | 'error'>('idle');
  const [syncMessage, setSyncMessage] = useState('');

  useEffect(() => {
    async function checkAdmin() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setAuthState('denied');
        return;
      }
      const { data: profile } = await supabase
        .from('profiles')
        .select('is_admin')
        .eq('id', session.user.id)
        .single();

      setAuthState(profile?.is_admin ? 'ok' : 'denied');
    }
    checkAdmin();
  }, []);

  async function handleSync() {
    setSyncStatus('syncing');
    setSyncMessage('');
    const { data: { session } } = await supabase.auth.getSession();

    const res = await fetch('/api/admin/sync', {
      method: 'POST',
      headers: { Authorization: `Bearer ${session?.access_token ?? ''}` },
    });
    const body = await res.json();

    if (!res.ok) {
      setSyncStatus('error');
      setSyncMessage(body.error ?? 'Sync failed');
      return;
    }
    setSyncStatus('done');
    setSyncMessage(`Synced ${body.synced} movies from TMDB.`);
  }

  if (authState === 'checking') {
    return <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center">Checking access...</div>;
  }

  if (authState === 'denied') {
    return (
      <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center px-6">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-3">Admin access required</h1>
          <p className="text-zinc-400 mb-6">
            Log in with an account that has <code className="text-rose-400">is_admin = true</code> in
            the profiles table (see <code className="text-rose-400">supabase/schema.sql</code>).
          </p>
          <Link href="/login" className="text-rose-400 underline">Go to login</Link>
        </div>
      </div>
    );
  }

  const stats = [
    { label: 'Total Movies', value: '1248', icon: Film },
    { label: 'Active Users', value: '45k', icon: Users },
    { label: 'Downloads Today', value: '392', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex">
      {/* Sidebar */}
      <div className="w-72 border-r border-zinc-800 bg-zinc-950 p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-12">
          <div className="text-2xl font-bold">blikmovies</div>
          <div className="px-2 py-0.5 text-xs bg-rose-600 rounded">ADMIN</div>
        </div>
        
        <nav className="space-y-1 flex-1">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
            { id: 'movies', label: 'Movies', icon: Film },
            { id: 'users', label: 'Users', icon: Users },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${activeTab === item.id ? 'bg-zinc-900 text-white' : 'hover:bg-zinc-900/50 text-zinc-400'}`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>
        
        <button className="flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-zinc-900 rounded-xl mt-auto">
          <LogOut className="w-5 h-5" /> Sign Out
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-10">
        {activeTab === 'dashboard' && (
          <div>
            <h1 className="text-5xl font-bold mb-12 tracking-tight">Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {stats.map((stat, i) => (
                <div key={i} className="bg-zinc-900 rounded-3xl p-8">
                  <div className="text-rose-500 mb-4"><stat.icon className="w-8 h-8" /></div>
                  <div className="text-6xl font-semibold tracking-tighter mb-1">{stat.value}</div>
                  <div className="text-zinc-400">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="bg-zinc-900 rounded-3xl p-8">
              <h3 className="text-xl mb-6">Recent Activity</h3>
              <div className="space-y-4 text-sm">
                {[1,2,3].map(i => (
                  <div key={i} className="flex justify-between py-3 border-b border-zinc-800 last:border-0">
                    <div>User approved download request for Interstellar</div>
                    <div className="text-zinc-500">2m ago</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'movies' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold">Movies Management</h1>
              <button
                onClick={handleSync}
                disabled={syncStatus === 'syncing'}
                className="bg-white text-black px-6 py-3 rounded-2xl font-medium disabled:opacity-50"
              >
                {syncStatus === 'syncing' ? 'Syncing...' : 'Sync from TMDB'}
              </button>
            </div>
            {syncMessage && (
              <p className={`mb-6 text-sm ${syncStatus === 'error' ? 'text-rose-400' : 'text-emerald-400'}`}>
                {syncMessage}
              </p>
            )}
            <div className="bg-zinc-900 rounded-3xl p-8 text-zinc-400">
              CRUD table would go here. Use TanStack Table in full implementation.
            </div>
          </div>
        )}

        {/* Add other tabs similarly */}
        {activeTab === 'users' && (
          <div className="bg-zinc-900 rounded-3xl p-8">
            <h1 className="text-4xl font-bold mb-8">Users &amp; Approvals</h1>
            <p className="text-zinc-400">Pending download approvals queue and user management table.</p>
          </div>
        )}
      </div>
    </div>
  );
}
