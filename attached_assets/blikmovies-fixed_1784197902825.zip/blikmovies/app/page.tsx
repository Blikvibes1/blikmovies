'use client';

import { useState, useEffect } from 'react';
import { Search, Play, Download, Star, Clock } from 'lucide-react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

// Fallback demo data, used only if the Supabase "movies" table is empty
// (run supabase/seed.sql in the Supabase SQL editor to populate real data)
// Kept in sync with supabase/seed.sql so the fallback and the real seeded
// data show the same (valid) TMDB image paths.
const mockMovies: Movie[] = [
  {
    id: 1,
    title: "Dune: Part Two",
    poster_path: "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9d7Z6J8w3e4vO.jpg",
    backdrop_path: "https://image.tmdb.org/t/p/original/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg",
    overview: "Paul Atreides unites with Chani and the Fremen while seeking revenge against his enemies.",
    vote_average: 8.5,
    release_date: "2024-03-01"
  },
  {
    id: 2,
    title: "Furiosa: A Mad Max Saga",
    poster_path: "https://image.tmdb.org/t/p/w500/iADOJ8Zymht2JPMoy3R7xceZprc.jpg",
    backdrop_path: "https://image.tmdb.org/t/p/original/dY5rDCXpvfBKttXo2yJnwlA9Rlw.jpg",
    overview: "The origin story of renegade warrior Furiosa before her encounter with Mad Max.",
    vote_average: 7.8,
    release_date: "2024-05-24"
  },
  {
    id: 3,
    title: "Kingdom of the Planet of the Apes",
    poster_path: "https://image.tmdb.org/t/p/w500/gKkl37BQuKTanygYQGz4c2mL7n.jpg",
    backdrop_path: "https://image.tmdb.org/t/p/original/wJGtCa2z8AZUAOx6ITEjEIu64Nx.jpg",
    overview: "An ape hunter embarks on a journey that will question all that he grew up believing.",
    vote_average: 7.1,
    release_date: "2024-05-10"
  },
  {
    id: 4,
    title: "Challengers",
    poster_path: "https://image.tmdb.org/t/p/w500/H6vke7Yx6NEjhVCTBTpzOTt3lpq.jpg",
    backdrop_path: "https://image.tmdb.org/t/p/original/2sxsRVhAZTgqjO0v0Yeo7pWRLCG.jpg",
    overview: "Tennis prodigy turned coach turns into the object of rivalry between two friends.",
    vote_average: 7.3,
    release_date: "2024-04-26"
  }
];

export default function BlikmoviesHome() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [heroMovie, setHeroMovie] = useState<Movie | null>(null);

  useEffect(() => {
    async function loadMovies() {
      const { data, error } = await supabase
        .from('movies')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (!error && data && data.length > 0) {
        setMovies(data as Movie[]);
        setHeroMovie(data[0] as Movie);
        return;
      }

      // Fallback demo data if the Supabase "movies" table is empty
      // (run supabase/seed.sql in the Supabase SQL editor to populate it)
      setMovies(mockMovies);
      setHeroMovie(mockMovies[0]);
    }
    loadMovies();
  }, []);

  const filteredMovies = movies.filter(movie => 
    movie.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-zinc-950 text-white overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-lg border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-rose-600 via-purple-600 to-indigo-600 rounded-xl flex items-center justify-center text-xl shadow-lg">
                ▶
              </div>
              <div className="text-3xl font-bold tracking-[-2px]">blikmovies</div>
            </div>
            <div className="hidden md:flex items-center gap-8 text-sm font-medium">
              <Link href="/" className="hover:text-rose-400 transition-colors">Home</Link>
              <Link href="/browse" className="hover:text-rose-400 transition-colors">Browse</Link>
              <Link href="/watchlist" className="hover:text-rose-400 transition-colors">My List</Link>
            </div>
          </div>

          <div className="flex-1 max-w-lg mx-8 relative hidden md:block">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 w-5 h-5" />
              <input
                type="text"
                placeholder="Search titles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 pl-12 py-3.5 rounded-2xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Link 
              href="/login"
              className="px-6 py-2.5 text-sm border border-zinc-700 hover:bg-zinc-900 rounded-2xl transition-colors"
            >
              Log in
            </Link>
            <Link 
              href="/admin"
              className="px-6 py-2.5 bg-white text-black font-semibold rounded-2xl hover:bg-zinc-100 transition-colors"
            >
              Admin
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      {heroMovie && (
        <div className="relative h-screen pt-16">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${heroMovie.backdrop_path})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />

          <div className="relative h-full max-w-4xl mx-auto px-6 flex flex-col justify-center z-10">
            <div className="max-w-2xl">
              <div className="text-rose-500 text-sm tracking-widest mb-4">EXCLUSIVE</div>
              <h1 className="text-7xl font-bold tracking-tighter leading-none mb-6">{heroMovie.title}</h1>
              <p className="text-zinc-300 text-lg mb-10 max-w-md">{heroMovie.overview}</p>
              
              <div className="flex gap-4">
                <Link href={`/movie/${heroMovie.id}`} className="flex items-center gap-3 bg-white text-zinc-950 px-10 py-4 rounded-2xl font-semibold hover:bg-zinc-200 transition-all">
                  <Play className="w-5 h-5" fill="currentColor" /> WATCH NOW
                </Link>
                <button 
                  onClick={() => alert('Download feature - requires approval')}
                  className="flex items-center gap-3 border border-white/70 px-8 py-4 rounded-2xl hover:bg-white/10 transition-all"
                >
                  <Download className="w-5 h-5" /> DOWNLOAD
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Movies Grid */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-4xl font-semibold tracking-tight">Trending Movies</h2>
          <Link href="/browse" className="text-sm text-rose-400 hover:underline">View all →</Link>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
          {filteredMovies.map(movie => (
            <Link key={movie.id} href={`/movie/${movie.id}`} className="group">
              <div className="relative aspect-[2/3] rounded-3xl overflow-hidden mb-4 bg-zinc-900">
                <img 
                  src={movie.poster_path} 
                  alt={movie.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                />
                <div className="absolute top-3 right-3 bg-black/70 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                  <Star className="w-3 h-3 text-yellow-400" /> {movie.vote_average}
                </div>
              </div>
              <div className="font-medium text-lg">{movie.title}</div>
              <div className="text-zinc-500 text-sm">{movie.release_date.split('-')[0]}</div>
            </Link>
          ))}
        </div>
      </div>

      {/* Simple Footer */}
      <footer className="bg-black py-12 border-t border-zinc-900 text-center text-sm text-zinc-500">
        Blikmovies © 2026 • Demo Project with Next.js + Supabase
      </footer>
    </div>
  );
}

interface Movie {
  id: number;
  title: string;
  poster_path: string;
  backdrop_path: string;
  overview: string;
  vote_average: number;
  release_date: string;
}
