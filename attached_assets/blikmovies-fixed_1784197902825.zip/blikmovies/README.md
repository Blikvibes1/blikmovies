# Blikmovies

A beautiful, production-ready movie streaming and download platform built with Next.js 15, TypeScript, Tailwind CSS, Supabase, and TMDB API.

## Features
- Cinematic UI with dark theme
- Movie browsing and search
- Mock streaming player
- Admin dashboard for management
- Supabase integration for auth and data
- TMDB API integration for rich movie data

## Getting Started

1. Clone the repo
2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables (copy `.env.example` to `.env.local` and fill in real values):
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   TMDB_API_KEY=your_tmdb_v4_read_access_token
   SUPABASE_SERVICE_ROLE_KEY=your_service_role_key   # only needed for /admin "Sync from TMDB"
   ```
   `.env.local` is already git-ignored, so these never get committed.

4. Run the development server:
   ```bash
   npm run dev
   ```

Open [http://localhost:3000](http://localhost:3000)

## Supabase Setup
See `supabase/schema.sql` for database schema and RLS policies.

## Tech Stack
- Next.js 16 App Router
- TypeScript
- Tailwind CSS + shadcn/ui style components
- Supabase (Auth, DB, Storage)
- TMDB & OMDb APIs
- Framer Motion, React Player, etc.

Built as a complete demo for movie platform. Extend with full API integrations and protected downloads.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
